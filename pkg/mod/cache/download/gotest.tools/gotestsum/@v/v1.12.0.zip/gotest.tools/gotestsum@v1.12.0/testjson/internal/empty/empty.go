//go:build stubpkg
// +build stubpkg

package empty
