package ignore_warnings

import "testing"

func TestIgnoreWarnings(t *testing.T) {
	t.Fail()
}
