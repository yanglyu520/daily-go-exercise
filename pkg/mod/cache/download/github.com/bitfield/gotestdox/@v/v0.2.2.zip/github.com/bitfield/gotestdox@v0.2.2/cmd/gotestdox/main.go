package main

import (
	"os"

	"github.com/bitfield/gotestdox"
)

func main() {
	os.Exit(gotestdox.Main())
}
