This is a fork of `spf13/pflag`.  See [gotestsum/issues/176](https://github.com/gotestyourself/gotestsum/issues/176#issuecomment-780854592).
